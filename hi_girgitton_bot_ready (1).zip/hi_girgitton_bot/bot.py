import os
import json
import asyncio
import logging
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

from telegram import Bot
from apscheduler.schedulers.asyncio import AsyncIOScheduler

TZ = ZoneInfo("Asia/Tashkent")
TOKEN = os.environ["BOT_TOKEN"]
CHANNEL_ID = os.environ["CHANNEL_ID"]  # @public_channel or numeric channel ID
POSTS_FILE = Path(__file__).with_name("posts.json")

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("hi-girgitton")

def load_posts():
    with POSTS_FILE.open("r", encoding="utf-8") as f:
        return json.load(f)

async def publish(bot: Bot, category: str):
    posts = load_posts()
    items = posts.get(category, [])
    if not items:
        log.warning("No posts configured for %s", category)
        return
    day_index = datetime.now(TZ).timetuple().tm_yday
    post = items[(day_index - 1) % len(items)]
    await bot.send_message(
        chat_id=CHANNEL_ID,
        text=post,
        disable_web_page_preview=True,
    )
    log.info("Published category=%s", category)

async def main():
    bot = Bot(TOKEN)
    scheduler = AsyncIOScheduler(timezone=TZ)
    scheduler.add_job(publish, "cron", hour=9, minute=0, args=[bot, "method"])
    scheduler.add_job(publish, "cron", hour=13, minute=0, args=[bot, "language"])
    scheduler.add_job(publish, "cron", hour=18, minute=0, args=[bot, "activity"])
    scheduler.start()
    log.info("Hi Girgitton scheduler started: 09:00, 13:00, 18:00 Asia/Tashkent")
    try:
        while True:
            await asyncio.sleep(3600)
    finally:
        scheduler.shutdown()
        await bot.shutdown()

if __name__ == "__main__":
    asyncio.run(main())
