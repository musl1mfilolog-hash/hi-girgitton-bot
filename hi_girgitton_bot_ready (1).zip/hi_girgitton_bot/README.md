# Hi Girgitton Telegram scheduler

This project posts three prepared Uzbek-language teaching posts per day:
- 09:00 — methodology
- 13:00 — Uzbek language/literature
- 18:00 — interactive activity

Timezone: Asia/Tashkent.

## Required environment variables
- `BOT_TOKEN` — create/revoke via @BotFather; never commit it to GitHub.
- `CHANNEL_ID` — public channel username (e.g. `@HiGirgitton`) or numeric channel ID.

The bot must be an administrator in the channel with permission to post messages.

## Run
```bash
pip install -r requirements.txt
python bot.py
```

The process must remain running for scheduled posts to be sent. A free hosting tier may sleep or stop the process, so it may not guarantee 24/7 scheduling.

## Important
The included posts are a small starter set that rotates. They are not live news and do not automatically verify current events. Add reviewed posts to `posts.json` before relying on the channel for current announcements.
